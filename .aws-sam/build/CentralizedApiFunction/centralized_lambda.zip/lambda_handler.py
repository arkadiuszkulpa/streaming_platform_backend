import json

def lambda_handler(event, context):
    try:
        path = event['rawPath']
        method = event['requestContext']['http']['method']

        if path == "/api" and method == "POST":
            # Parse the request body
            body = json.loads(event.get('body', '{}'))
            action = body.get('action')

            # Route the action to the appropriate function
            if action == "get_movie_info":
                return get_movie_info(body)
            elif action == "search_movies":
                return search_movies(body)
            elif action == "update_user_settings":
                return update_user_settings(body)
            elif action == "get_homepage_data":
                return get_homepage_data(body)
            else:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "Invalid action"})
                }
        else:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "Not Found"})
            }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

def get_movie_info(body):
    # Logic for fetching movie info
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Movie info fetched successfully"})
    }

def search_movies(body):
    # Logic for searching movies
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Movies searched successfully"})
    }

def update_user_settings(body):
    # Logic for updating user settings
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "User settings updated successfully"})
    }

def get_homepage_data(body):
    # Logic for fetching homepage data
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Homepage data fetched successfully"})
    }